#include <iostream>
#include "include/gunCL.h"
#include "include/paintCL.h"

using namespace std;

void showMainMenu() {}

void Arsenal()
{
    cout<<"Arsenal entered"<<endl;
    paintCL picture;
    picture.draw(1);

}

int main()
{
	while(1)
	{
		int choice = 0;
		showMainMenu();
		cin>>choice;
		switch(choice)
		{
			case 1:
				Arsenal();
				break;
			case 2:
				return 0;
				break;
			default:
				cout<<"Again";
		}
	}
	return 0;
}
