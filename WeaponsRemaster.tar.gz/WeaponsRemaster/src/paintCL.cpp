#include "../include/paintCL.h"
#include <iostream>

using namespace std;

paintCL::paintCL()
{

}

void paintCL::draw(int n)
{
	switch(n)
	{
		case 0:
			cout<<" ,________________________________       "<<endl;
			cout<<"|__________,----------._ [____]  \"\"-,__  __...-----===\""<<endl;
			cout<<"        (_(||||||||||||)___________/   \"\"             |"<<endl;
			cout<<"           `----------'        [ ))\"-,                |"<<endl;
			cout<<"                                \"\"    `,  _,--...___  |"<<endl;
			cout<<"                                        `/          \"\"\""<<endl;
			break;
		case 1:
			cout<<"                           ______"<<endl;
			cout<<"        |\\_______________ (_____\\\\______________"<<endl;
			cout<<"HH======#H###############H#######################"<<endl;
			cout<<"        ' ~\"\"\"\"\"\"\"\"\"\"\"\"\"\"`##(_))#H\\\"\"\"\"\"Y########"<<endl;
			cout<<"                          ))    \\#H\\       `\"Y###"<<endl;
			cout<<"                          \"      }#H)"<<endl;
			break;
		case 2:
			cout<<"+--^----------,--------,-----,--------^-,"<<endl;
			cout<<"| |||||||||   `--------'     |          O"<<endl;
			cout<<"`+---------------------------^----------|"<<endl;
			cout<<"  `\\_,---------,---------,--------------'"<<endl;
			cout<<"     / XXXXXX /'|       /'"<<endl;
			cout<<"    / XXXXXX /  `\\    /'"<<endl;
			cout<<"   / XXXXXX /`-------'"<<endl;
			cout<<"  / XXXXXX /"<<endl;
			cout<<" / XXXXXX /"<<endl;
			cout<<"(________(         "<<endl;
			cout<<" `------'    "<<endl;
			break;
	}
}

paintCL::~paintCL()
{
    //dtor
}
