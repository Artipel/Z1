#include "../include/gunCL.h"

gunCL::gunCL()
{
    //ctor
}

gunCL::~gunCL()
{
    //dtor
}

gunCL::gunCL(int m, string n, int g, int mm, int ms, int ml)
{
    setModel(n);
    setGraphics(g);
    ownClip.redefine(mm, ms, ml);
    setOwnWeight(m);
    updateWeight();
    //Gun::ammo=0;
}

void gunCL::redefine(int m, string n, int g, int mm, int ms, int ml)
{
    setOwnWeight(m);
    setModel(n);
    setGraphics(g);
    attachClip(mm, ms, ml);
    updateWeight();
}

void gunCL::attachClip(int m, int s, int l)
{
    ownClip.redefine(m, s, l);
    //cout<<"Clip attached. Ammo: "<<Gun::ownClip.getLoad()<<endl;
    updateWeight();
}

void gunCL::setOwnWeight(int m)
{
    ownWeight = m;
}

void gunCL::updateWeight()
{
    totalWeight = ownWeight + ownClip.getWeight();
}

void gunCL::setModel(string n)
{
    model=n;
}

void gunCL::setGraphics(int n)
{
    graphics=n;
}

int gunCL::getWeight() const
{
    return totalWeight;
}

string gunCL::getModel() const
{
    return model;
}

void gunCL::shot()
{
    if(ownClip.unload()==1)
    {
        cout<<"**BANG**"<<endl;
        updateWeight();
    }
}

void gunCL::reload()
{
    int temp;
    temp = ownClip.getLoad();
    ownClip.reload();
    cout<<"Weapon reloaded. Ammo: "<<ownClip.getLoad()<<endl;
    ammo-=(ownClip.getLoad()-temp);
    updateWeight();
    cout<<"Ammo available in the stock: ";
    cout<<ammo<<endl;

}

void gunCL::drawGun() const
{
    paintCL paint;
    paint.draw(graphics);
}

void gunCL::setAmmo(int x)
{
    gunCL::ammo = x;
}

int gunCL::getAmmo()
{
    return ammo;
}

bool gunCL::operator >(const gunCL & g)
{
    return this->totalWeight>g.totalWeight;
}

bool gunCL::operator <(const gunCL & g)
{
    return this->totalWeight<g.totalWeight;
}

ostream & gunCL::operator<< (ostream &wyjscie, const gunCL &g)
{
    g.drawGun();
    return wyjscie <<"Name: "<<g.model<<endl<<"Total weight: "<<g.totalWeight<<endl<<"Clip weight: "<<g.ownClip.getWeight()<<endl<<"Clip size: "<<g.ownClip.getSize()<<endl;
}
