#include "../include/clipCL.h"

clipCL::clipCL()
{
    //ctor
}

clipCL::~clipCL()
{
    //dtor
}
