#ifndef PAINTCL_H
#define PAINTCL_H


class paintCL
{
    public:
        paintCL();
        void draw(int);
        virtual ~paintCL();
    protected:
    private:
};

#endif // PAINTCL_H
