#ifndef GUNCL_H
#define GUNCL_H
#include <iostream>
#include <string>
#include "paintCL.h"
#include "clipCL.h"

using namespace std;

class gunCL
{
    public:
        gunCL();

        virtual ~gunCL();

        gunCL(int m, string n, int g, int mm, int ms, int ml);

        void redefine(int m, string n, int g, int mm, int ms, int ml);

        void attachClip(int m, int s, int l);

        void setOwnWeight(int m);

        void updateWeight();

        void setModel(string n);

        void setGraphics(int n);

        int getWeight() const;

        string getModel() const;

        void shot();

        void reload();

        void drawGun() const;

        static void setAmmo(int x);

        static int getAmmo();

        bool operator >(const gunCL & g);

        bool operator <(const gunCL & g);

        friend ostream & operator<< (ostream &wyjscie, const gunCL &g);

    private:
        int totalWeight;
        int ownWeight;
        string model;
        int graphics;
        clipCL ownClip;
        static int ammo;
};

#endif // GUNCL_H
