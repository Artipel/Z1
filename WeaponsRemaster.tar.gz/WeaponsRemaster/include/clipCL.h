#ifndef CLIPCL_H
#define CLIPCL_H


class clipCL
{
    public:
        clipCL();
        void redefine(int, int, int);
        virtual ~clipCL();
        int getWeight();
        int unload();
        int getLoad();
        void reload();
    protected:
    private:
};

#endif // CLIPCL_H
